from eloquent_edgeimpulse.fomo import Fomo
